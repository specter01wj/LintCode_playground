Notes:
System ouput: What out for format with space: " "
Don't println() when print() is needed.
	Or: can choose to build a String rst, and print at the end.

Be careful with root node : ) always

Safe way to do LCA on Binary Search Tree: traditional way of 2 lists


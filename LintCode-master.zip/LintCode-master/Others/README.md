# Other Problems

This section captures other programs that does not appear in LintCode. There might not be a clear solution to problems here, but here we'll try to capture some 'how to' or good thoughts.

And, due to the non-consistency, there won't be auto-generated list view : ).

# Leetcode-solution-in-JavaScript
This repo contains solutions for lintcode's problem.<br>
There is a file called lintcode_leetcode.txt <br>
It is a file for matching lintcode problem to leetcode problem. <br>
So you can run the solution on leetcode platform <br><br>

All the solutions is coding in JavaScript. <br>
All the solution file starts with number as prefix, which is the problem number in lintcode <br>
All the solution has problem description inside and explanation.<br>
so far, I finish problems, starting from easy problems. <br>
I will keep updating.. stay tune.......<br>
If you have any question, please send email to
<a href='mailto: johnnyhsu1106@gmail.com'>johnnyhsu1106@gmail.com</a>

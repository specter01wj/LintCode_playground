# Same Tree

> Given two binary trees, write a function to check if they are equal or not.
> 
> Two binary trees are considered equal if they are structurally identical and the nodes have the same value.

## Solution 1

Recursive:

Base cases are:

* Both node are NULL;
* One node is NULL and the other one is not;
* Two nodes(value) are not equal.

## Solution 2

Iterative:

Comming soon...

## Sources

See also: [Binary Tree](https://github.com/T1ger/LeetCode/tree/master/src/maximum_depth_of_binary_tree#binary-tree), [Recursion](https://github.com/T1ger/LeetCode/tree/master/src/maximum_depth_of_binary_tree#recursion)
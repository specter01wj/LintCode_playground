# Reverse Linked List

> Reverse a singly linked list.

## Follow up

A linked list can be reversed either iteratively or recursively. Could you implement both?

## Solution

- Iteratively: [Java](solution1.java)
- Recursively: __To do__

## Source

[LeetCode 206](https://leetcode.com/problems/reverse-linked-list/)
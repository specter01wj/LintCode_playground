# Binary Tree Maximum Path Sum 

> Given a binary tree, find the maximum path sum from root.

> The path may start and end at any node in the tree.

> __Example__

> Given the below binary tree:

```
  1
 / \
2   3
```

> return `6`.

## Solution

node value could be negative

## Source

[LintCode](http://www.lintcode.com/en/problem/binary-tree-maximum-path-sum/)
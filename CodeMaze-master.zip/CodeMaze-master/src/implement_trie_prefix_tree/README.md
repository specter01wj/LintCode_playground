# Implement Trie (Prefix Tree)

> Implement a trie with `insert`, `search`, and `startsWith` methods.

## Notice

- You may assume that all inputs are consist of lowercase letters `a-z`.

## Solution

- [Java](solution1.java)


## Source

[LeetCode 208](https://leetcode.com/problems/implement-trie-prefix-tree/)
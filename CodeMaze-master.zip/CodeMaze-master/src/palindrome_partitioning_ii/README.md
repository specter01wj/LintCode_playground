# Palindrome Partitioning II

> Given a string s, cut s into some substrings such that every substring is a palindrome.

> Return the minimum cuts needed for a palindrome partitioning of s.

> __Example__

Given s = `"aab"`,

Return `1` since the palindrome partitioning ["aa", "b"] could be produced using 1 cut.

## Solution



## Source

[LintCode](http://www.lintcode.com/en/problem/palindrome-partitioning-ii/)
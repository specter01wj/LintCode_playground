# Binary Tree Preorder

> Given a binary tree, return the preorder traversal of its nodes' values

## Example

Given:

```
    1
   / \
  2   3
 / \
4   5
```

return `[1,2,4,5,3]`

## Challenge

Can you do it without recursion?

## Solution


## Source

[LintCode](https://www.lintcode.com/en/problem/binary-tree-preorder-traversal/)
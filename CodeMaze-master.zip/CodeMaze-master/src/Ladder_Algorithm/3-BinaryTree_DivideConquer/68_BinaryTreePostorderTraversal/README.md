# Binary Tree Postorder Traversal

> Given a binary tree, return the postorder traversal of its nodes' values

## Example

Given: `{1,#,2,3}`

```
    1
     \
      2
     /
    3
```

return `[3,2,1]`

## Challenge

Can you do it without recursion?

## Solution


## Source

[LintCode](https://www.lintcode.com/en/problem/binary-tree-postorder-traversal/)
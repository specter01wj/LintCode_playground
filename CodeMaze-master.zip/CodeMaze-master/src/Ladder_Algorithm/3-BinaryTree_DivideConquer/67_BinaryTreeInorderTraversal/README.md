# Binary Tree Inorder Traversal

> Given a binary tree, return the inorder traversal of its nodes' values

## Example

Given: `{1,#,2,3}`

```
    1
     \
      2
     /
    3
```

return `[1,3,2]`

## Challenge

Can you do it without recursion?

## Solution


## Source

[LintCode](https://www.lintcode.com/en/problem/binary-tree-inorder-traversal/)
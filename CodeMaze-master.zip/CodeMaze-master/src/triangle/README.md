# Triangle

> Given a triangle, find the minimum path sum from top to bottom. Each step you may move to adjacent numbers on the row below.

> __Notice__

> Bonus point if you are able to do this using only O(n) extra space, where n is the total number of rows in the triangle.

> __Example__

```
[
     [2],
    [3,4],
   [6,5,7],
  [4,1,8,3]
]
```

## Solution



## Source

[LintCode](http://www.lintcode.com/en/problem/triangle/)
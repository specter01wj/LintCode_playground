# Plus One Linked List

> Given a non-negative integer represented as __non-empty__ a singly linked list of digits, plus one to the integer.
> 
> You may assume the integer do not contain any leading zero, except the number 0 itself.
>
> The digits are stored such that the most significant digit is at the head of the list.

## Example

```
Input:
1->2->3

Output:
1->2->4
```

## Solution

[Java](solution1.java)

## Source

[LeetCode 369](https://leetcode.com/problems/plus-one-linked-list/)
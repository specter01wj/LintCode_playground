# Minimum Path Sum

> Given a `m x n` grid filled with non-negative numbers, find a path from top left to bottom right which __minimizes__ the sum of all numbers along its path.

> __Notice__

> You can only move either down or right at any point in time.

## Solution

don't forget to init `f[0][0]`

## Source

[LintCode](http://www.lintcode.com/en/problem/minimum-path-sum/)
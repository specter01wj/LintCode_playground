# Binary Tree Maximum Path Sum II

> Given a binary tree, find the maximum path sum from root.

> The path may end at any node in the tree and contain at least one node in it.

> __Example__

> Given the below binary tree:

```
  1
 / \
2   3
```

> return `4`. (1->3)

## Solution

node value could be negative

## Source

[LintCode](http://www.lintcode.com/en/problem/binary-tree-maximum-path-sum-ii/)